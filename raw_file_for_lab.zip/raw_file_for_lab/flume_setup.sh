#!/bin/bash
hadoop fs -mkdir -p /user/cloudera/impressions/
hadoop fs -chmod 777 /user/cloudera/impressions/
sudo mkdir /tmp/impressions
sudo chmod 777 /tmp/impressions
sudo mkdir /tmp/flume
sudo chmod 777 /tmp/flume
