#!/usr/bin/env python3
import sys

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split(',')
    if len(parts) != 3:
        continue
    person_id, district_id, income = parts

    try:
        income = float(income)
        print(f"{district_id}\t{income}")
    except ValueError:
        continue

