#!/usr/bin/env python3
import sys

current_district = None
total_income = 0.0
count = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    district_id, income = line.split('\t')
    income = float(income)

    if current_district == district_id:
        total_income += income
        count += 1
    else:
        if current_district is not None:
            avg_income = total_income / count
            print(f"{current_district}\t{avg_income:.2f}")
        current_district = district_id
        total_income = income
        count = 1

if current_district is not None:
    avg_income = total_income / count
    print(f"{current_district}\t{avg_income:.2f}")